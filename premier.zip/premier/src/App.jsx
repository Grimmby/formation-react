import "./App.css";
import {useRef, useState} from 'react';

export default function App() {
	const [message,setMessage] = useState({
		imc: '',
		text: '',
		className: '',
	})
	const poids = useRef('');
	const taille = useRef('');

	const calculIMC = (event)=> {
		if( event.target.name =='poids' ){
			poids.current = event.target.value;
		} else if( event.target.name =='taille' ){
			taille.current = event.target.value;
		}
		
		const info = {};
		const imc = poids.current / (taille.current * taille.current);
		
		if( poids.current > 0 && taille.current > 0 ) {
			info.imc = imc.toFixed(1);
			if( imc < 18.5 ) {
				info.text = "Maigreur";
				info.className = "alert-warning";
			} else if ( imc < 25 ) {
				info.text = "Normal";
				info.className = "alert-success";
			} else if ( imc < 30 ) {
				info.text = "Surpoids";
				info.className = "alert-warning";
			} else if ( imc < 35 ) {
				info.text = "Obésité";
				info.className = "alert-warning";
			} else if ( imc < 40 ) {
				info.text = "Obésité massive";
				info.className = "alert-danger";
			} else if ( imc > 40 ) {
				info.text = "Obésité sévère";
				info.className = "alert-danger";
			}
		}
		
		setMessage(info);
	};
	return (
		<>
			<nav className="navbar navbar-expand-lg navbar-dark bg-dark">
				<div className="container">
					<a className="navbar-brand" href="#">
						<i className="fa-solid fa-weight-scale"></i>
						Calcul IMC
					</a>
				</div>
			</nav>
			<div className="container">
				<div className="row">
					<form method="post" onSubmit={calculIMC} className="col-4 pt-4">
						<h1 className="h3">Calculer votre IMC</h1>
						<input name="poids"
							aria-label="Poids"
							className="form-control"
							placeholder="Poids en kg."
							onChange={calculIMC}
						/>
						
						<input name="taille"
							aria-label="Taille"
							className="form-control mt-3"
							placeholder="taille en m."
							onChange={calculIMC}
						/>
						{/* <button type="submit" className="btn btn-success mt-3 col-12">
							<i className="fa-solid fa-weight-scale"></i>
						</button> */}
						
						{message.imc && (
							<div className={`alert mt-4 ${message.className}`} role="alert">
								<h3>IMC : {message.imc}</h3>
								<p>{message.text}</p>
							</div>
						)}
					</form>
				</div>
			</div>
		</>
	);
}