import './App.css'
import AppareilComponent from './components/AppareilComponent.jsx'

export default function App() {
	return (
		<>
			<div>Hello World</div>
			{/* <AppareilComponent name="Playstation 5" status="true" />
			<AppareilComponent name="Xbox" status="false" />
			<AppareilComponent name="Machine à café" status="true" /> */}
		</>
	)
}