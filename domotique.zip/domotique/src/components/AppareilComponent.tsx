// function AppareilComponent(props){
//     return (
//         <>
//             <p>
//                 Name: {props.name}
//             </p>
//             <div>
//                 Status: {props.status}
//             </div>
//         </>
//     );
// }

function Personne() {
    
}